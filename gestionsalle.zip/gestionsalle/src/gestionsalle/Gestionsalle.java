package gestionsalle;
import vue.*;
public class Gestionsalle {

    public static void main(String[] args) {
        Formprincipal  f = new Formprincipal();
        f.setSize(800,800);
        f.setTitle("Gestion des salles universitaires");
        f.setVisible(true);
    }
    
}
